/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mattress;

/**
 *
 * @author Student
 */

public class Product implements IProduct {

    private String[] productNames;
    private int[][] monthlySales;

    // Constructor to initialise product names and monthly sales
    public Product(String[] productNames, int[][] monthlySales) {
        this.productNames = productNames;
        this.monthlySales = monthlySales;
    }

    // Calculate the total number of products sold
    @Override
    public int GetTotalProductsSold() {
        int total = 0;

        for (int[] sales : monthlySales) {
            for (int sale : sales) {
                total += sale;
            }
        }

        return total;
    }

    // Calculate the average sales per product per month
    @Override
    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int numberOfSales = 0;

        for (int[] sales : monthlySales) {
            numberOfSales += sales.length;
        }

        return (double) total / numberOfSales;
    }

    // Identify the product with the highest total sales
    @Override
    public String GetMostPopularProduct() {
        int highestSales = -1;
        String mostPopular = "";

        for (int i = 0; i < monthlySales.length; i++) {
            int productTotal = 0;

            for (int sale : monthlySales[i]) {
                productTotal += sale;
            }

            if (productTotal > highestSales) {
                highestSales = productTotal;
                mostPopular = productNames[i];
            }
        }

        return mostPopular;
    }
}
