/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.mattress;

/**
 *
 * @author Student
 */
public class MattressSalesReport {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
