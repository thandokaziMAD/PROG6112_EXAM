/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mattress;

/**
 *
 * @author Student
 */


public class PrintProduct {

    // Print the total number of products sold
    public void PrintTotalSales(Product product) {
        System.out.println("TOTAL PRODUCT SALES: "
                + product.GetTotalProductsSold());
    }

    // Print the average number of products sold
    public void PrintAverageSales(Product product) {
        System.out.println("AVERAGE PRODUCT SALES: "
                + Math.round(product.GetAverageProductSold()));
    }

    // Print the most popular product
    public void PrintMostPopularProduct(Product product) {
        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct());
    }

    // Display the complete sales report
    public void PrintReport(Product product) {
        System.out.println("\nPRODUCT SALES REPORT - 2026");
        System.out.println("***************************************");

        PrintTotalSales(product);
        PrintAverageSales(product);
        PrintMostPopularProduct(product);
    }
}
