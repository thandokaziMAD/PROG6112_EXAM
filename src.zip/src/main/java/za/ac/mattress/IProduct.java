/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.mattress;

/**
 *
 * @author Student
 */

public interface IProduct {

    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}
